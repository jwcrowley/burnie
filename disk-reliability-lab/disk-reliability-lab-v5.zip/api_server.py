from fastapi import FastAPI
import sqlite3

app=FastAPI()

@app.get("/disks")
def disks():
 conn=sqlite3.connect("disks.db")
 rows=conn.execute("select serial,model,reliability_score from disks").fetchall()
 return [{"serial":r[0],"model":r[1],"score":r[2]} for r in rows]
