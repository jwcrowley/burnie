# Disk Reliability Lab v5

Full-featured disk validation and reliability analysis platform inspired by
large-scale storage operators.

Features
- HDD / SSD / NVMe burn-in testing
- Sequential + random stress validation
- SMART + NVMe health ingestion
- Reliability scoring engine
- SMART failure heuristics
- Latency anomaly detection
- Thermal monitoring hooks
- Batch drive testing
- Artifact storage
- SQLite or PostgreSQL support
- FastAPI REST API
- Prometheus metrics exporter
- Grafana dashboards
- Simple web UI
- Docker deployment
- Vendor / batch tracking
