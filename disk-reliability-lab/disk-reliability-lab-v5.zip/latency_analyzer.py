import glob,statistics

def analyze(serial):
 files=glob.glob(f"artifacts/{serial}/latency*")
 values=[]
 for f in files:
  with open(f) as fh:
   for line in fh:
    parts=line.split()
    if len(parts)>1:
     values.append(float(parts[-1]))
 if not values:
  return None
 p99=statistics.quantiles(values,n=100)[98]
 return p99
